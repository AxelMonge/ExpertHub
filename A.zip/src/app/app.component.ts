import { Component, AfterViewInit } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
  title = 'experthub';

  ngAfterViewInit() {
    // Animación inicial para que la app se sienta viva
    const sections = document.querySelectorAll('header, .sell-nft, .nft-shop, .sellers, footer');
    sections.forEach((section, index) => {
      setTimeout(() => {
        section.classList.add('fade-in');
      }, index * 200); // Retraso progresivo para animación
    });
  }

  scrollTo(section: string) {
    let element;
    if (section === 'inicio') element = document.getElementById('inicio');
    if (section === 'caracteristicas') element = document.querySelector('h2.separator'); // Scroll a "Conecta con Profesionales"
    if (section === 'acerca') element = document.querySelector('#acerca');
    if (element) {
      const offsetTop = element.getBoundingClientRect().top + window.scrollY - 100;
      window.scrollTo({ top: offsetTop, behavior: 'smooth' });
    }
  }

  showModal(modalType: string) {
    const contactModal = document.getElementById('contactModal');
    const footerModal = document.getElementById('footerModal');
    if (contactModal && footerModal) {
      if (modalType === 'contact') {
        contactModal.style.display = 'flex';
      } else if (modalType === 'footer') {
        footerModal.style.display = 'flex';
      }
    } else {
      console.error('Modals not found in DOM');
    }
  }

  closeModal(modalType: string) {
    const contactModal = document.getElementById('contactModal');
    const footerModal = document.getElementById('footerModal');
    if (contactModal && footerModal) {
      if (modalType === 'contact') {
        contactModal.style.display = 'none';
      } else if (modalType === 'footer') {
        footerModal.style.display = 'none';
      }
    }
  }
}
