export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAnv08-vrmwvTBUaPo6ed9fKaTpJKUlojI",
    authDomain: "experthub-271ae.firebaseapp.com",
    projectId: "experthub-271ae",
    storageBucket: "experthub-271ae.firebasestorage.app",
    messagingSenderId: "1070169013983",
    appId: "1:1070169013983:web:4a1597ef7f2316b0fa736a"
  }
};
